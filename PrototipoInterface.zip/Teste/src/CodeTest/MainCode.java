package CodeTest;

import java.util.Scanner;

public class MainCode {
	public static String UserCode;
	
	public static void main(String[] args) {
		// Cria um objeto para armazenar o código do usuário
		Texto Texto1 = new Texto();
		Scanner scanner = new Scanner(System.in);
		String LinhaAtual;
		
		do {
			LinhaAtual = UserCode;
			Texto1.setTexto(LinhaAtual);
		} while (!LinhaAtual.equals("}"));
		
		System.out.print(Texto1.getTexto());
	}
}