package CodeTest;

import java.util.ArrayList;

public class Texto {
	private ArrayList<String> TextoCompleto = new ArrayList<>();
	private String LinhaUnica = "";
	
	// Junta todas as linhas em um Array e em uma única linha
	public void setTexto(String linha) {
		TextoCompleto.add(linha);
		
		if (!linha.equals("}")) {
			linha = linha.replace("\t", "");
			LinhaUnica += linha + " ";
		}
		else {
			LinhaUnica += linha;
		}
	}

	// Manda o código para a IA
	public String getTexto() {
		return LinhaUnica;
	}
}