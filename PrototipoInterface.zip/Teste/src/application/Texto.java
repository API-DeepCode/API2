package application;

public class Texto {
	private String[] textoCompleto;
	static String linhaUnica = "";

	// Cria uma Array e uma única linha com o código completo
	public void setTexto(String texto) {
		textoCompleto = texto.split("\n");
		
		for (int i = 0; i < textoCompleto.length; i++) {
			String linhaAtual = textoCompleto[i];

			if (!textoCompleto[i].equals("}")) {
				linhaAtual = linhaAtual.replace("\t", "");
				linhaUnica += linhaAtual + " ";
			}
			else {
				linhaUnica += linhaAtual;
			}
		}
	}
	
	// Manda o código para a IA
	public String getTexto() {
		return linhaUnica;
	}
}