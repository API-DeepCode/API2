package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.scene.control.Button;

import CodeTest.MainCode;

public class Main extends Application {
	// Classe da tela principal
    public void start(Stage TelaPrincipal) {
        // Criando um TextArea para o usuário digitar código
        TextArea CodeArea = new TextArea();
        CodeArea.setPrefSize(600, 400);

        // Butão para enviar o código para a IA
        Button btnSendCode = new Button("Enviar código");
        
        // Criando a página principal
        VBox root = new VBox(CodeArea, btnSendCode);
        VBox.setMargin(CodeArea, new Insets(10, 20, 10, 20));
        
        // Criando a cena
        Scene scene = new Scene(root, 800, 600);
        
        // Importando CSS
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        
        // Funcionalidade do botão btnSendCode
        btnSendCode.setOnAction(event -> {
        	String codigo = CodeArea.getText();
        	SendCode(codigo);        	
        });
        	
        // Configurando o palco (janela)
        TelaPrincipal.setTitle("DeepCode");
        TelaPrincipal.setScene(scene);
        TelaPrincipal.show();
    }
	
	public static void main(String[] args) {
		launch(args);
	}
	
	// Classe para enviar a informação para outro arquivo
	private void SendCode(String codigo) {		
		MainCode.UserCode = codigo;
	}
}
